const { Schema, model } = require('mongoose')

const Database = new Schema({
    guild: String,
    user: String,
    password: Number,
    c1: {
        cash: { type: Number, default: 0 },
        bank: { type: Number, default: 0 },
        id: Object,
        m5alfat: Array,
        inv: Array
    },
    c2: {
        cash: { type: Number, default: 0 },
        bank: { type: Number, default: 0 },
        id: Object,
        m5alfat: Array,
        inv: Array
    },
    points: {
        start_game: { type: Number, default: 0 },
        join_game: { type: Number, default: 0 },
        claim: { type: Number, default: 0 },
        gmc: { type: Number, default: 0 },
        tf3el: { type: Number, default: 0 },
        others: { type: Number, default: 0 }
    }
})

module.exports = model("userBase", Database)