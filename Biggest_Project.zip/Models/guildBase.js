const { Schema, model } = require('mongoose')

const Database = new Schema({
    guild: String,
    store: Array,
    staff_points: String,
    invbank: String,
    password_admin: String,
    mo_listadmin: String,
    auto_line: {
        channels: Array,
        line: String
    },
    police: String,
    mo5alfat: Array,
    claimed: Array,
    id_role: String,
    reasons: Array,
    blacklist: String,
    blacklist_channel: String,
    thefts: Array,
    staff: {
        role: String
    },
    channels: {
        main_game: String,
        second_game: String,
        bank: String
    },
    da5lya: {
        main_channel: String,
        second_channel: String
    },
    joins: Array,
    jobs: Array,
    tf3el: {
        add_role: Array,
        remove_role: Array,
        log: String
    }
})

module.exports = model("guildBase", Database)