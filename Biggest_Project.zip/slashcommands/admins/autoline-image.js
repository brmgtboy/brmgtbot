const guildBase = require('../../Models/guildBase')
module.exports = {
  name: `auto-line-image`,
  description: "لتعين الخط التلقائي",
  default_member_permissions: "0x0000000000000008",
  options: [
    {
        name: "image",
        type: "ATTACHMENT",
        description: "لإضافة صورة الخط التلقائي",
        required: true
    }
  ],
  run: async (client, interaction, Discord) => {
    if(interaction.commandName == "auto-line-image") {
        let image = interaction.options.getAttachment("image")
        , subcommand = interaction.options._subcommand

        let db = await guildBase.findOne({ guild: interaction.guild.id })
        if(!db) {
            db = new guildBase({ guild: interaction.guild.id })
            await db.save()
        }

        db.auto_line["line"] = image.proxyURL
        await db.save()
  
        await interaction.reply({ 
            content: `:white_check_mark: تم تعين صورة الخط التلقائي بنجاح`, 
            ephemeral: true 
        })
    }
  }
};
