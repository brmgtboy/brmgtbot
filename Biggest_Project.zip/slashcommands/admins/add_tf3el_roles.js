const guildBase = require('../../Models/guildBase')
module.exports = {
  name: `add-tf3el-roles`,
  description: "لتعين رولات التفعيل",
  default_member_permissions: "0x0000000000000008",
  options: [
    {
        name: "action",
        description: "اختر نوع الرول",
        required: true,
        type: "STRING",
        choices: [
            { name: "Add", value: "add" },
            { name: "Remove", value: "remove" }
        ]
    },
    {
      name: "role",
      description: "ارفق الرول الذي تريد تعينها",
      type: "ROLE",
      required: true
    }
  ],
  run: async (client, interaction, Discord) => {
    if(interaction.commandName == "add-tf3el-roles") {
        let action = interaction.options.getString("action"),
        role = interaction.options.getRole("role");

        let db = await guildBase.findOne({ guild: interaction.guild.id })
        if(!db) {
            db = new guildBase({ guild: interaction.guild.id })
            await db.save()
        }

        if(db.tf3el[action == "add" ? "add_role" : "remove_role"].includes(role.id)) return interaction.reply({
            content: `تم إضافة هذه الرول من قبل لهذا القسم`,
            ephemeral: true
        })

        db.tf3el[action == "add" ? "add_role" : "remove_role"].push(role.id)
        await db.save()
  
        await interaction.reply({ content: `:white_check_mark: تم تعين رولات التفعيل بنجاح!`, ephemeral: true })
    }
  }
};
