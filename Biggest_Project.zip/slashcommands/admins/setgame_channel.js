const guildBase = require('../../Models/guildBase')
module.exports = {
  name: `set-game-channels`,
  description: "لتعين رومات الاقيام",
  default_member_permissions: "0x0000000000000008",
  options: [
    {
        name: "channel_1",
        type: "CHANNEL",
        description: `الروم اللى هتروح له رسايل الاقيام`,
        required: true,
        channel_types: ["0"]
    },
    {
        name: "channel_2",
        type: "CHANNEL",
        description: `الروم اللى هتروح له رسايل تم فتح القيم`,
        required: true,
        channel_types: ["0"]
    }
  ],
  run: async (client, interaction, Discord) => {
    if(interaction.commandName == "set-game-channels") {
      let main_channel = interaction.options.getChannel("channel_1"),
      second_channel = interaction.options.getChannel("channel_2");

      let db = await guildBase.findOne({ guild: interaction.guild.id })
      if(!db) {
        db = new guildBase({ guild: interaction.guild.id })
        await db.save()
      }

      db.channels["main_game"] = main_channel.id,
      db.channels["second_game"] = second_channel.id
      await db.save()

      interaction.reply({ content: `:white_check_mark: تم تعين رومات الاقيام بنجاح`, ephemeral: true })
    }
  }
};
