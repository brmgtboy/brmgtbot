const guildBase = require('../../Models/guildBase')
module.exports = {
  name: `reset-all-reasons`,
  description: "لحذف جميع العقوبات",
  default_member_permissions: "0x0000000000000008",
  run: async (client, interaction, Discord) => {
    if(interaction.commandName == "reset-all-reasons") {
        let db = await guildBase.findOne({ guild: interaction.guild.id })
        if(!db) {
            db = new guildBase({ guild: interaction.guild.id })
            await db.save()
        }

        db.reasons = []
        await db.save()
  
        await interaction.reply({ content: `:white_check_mark: تم حذف جميع العقوبات`, ephemeral: true })
    }
  }
};
