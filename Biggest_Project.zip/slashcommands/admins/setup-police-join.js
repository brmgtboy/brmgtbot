const guildBase = require('../../Models/guildBase')
    , { sleep } = require('../../functions')
    , Discord = require('discord.js')

module.exports = {
    name: `setup-police-joins`,
    description: "لتعين اعدادات الداخلية",
    default_member_permissions: "0x0000000000000008",
    options: [
        {
            name: "main_channel",
            type: "CHANNEL",
            description: `الروم اللى هتروح له رسايل الازرار`,
            required: true,
            channel_types: ["0"]
        },
        {
            name: "second_channel",
            type: "CHANNEL",
            description: `الروم اللى هتروح له قائمة المباشرين `,
            required: true,
            channel_types: ["0"]
        }
    ],
    run: async (client, interaction) => {
        if (interaction.commandName == "setup-police-joins") {
            let main_channel = interaction.options.getChannel("main_channel"),
                second_channel = interaction.options.getChannel("second_channel");

            let db = await guildBase.findOne({ guild: interaction.guild.id })
            if (!db) {
                db = new guildBase({ guild: interaction.guild.id })
                await db.save()
            }

            db.da5lya = { main_channel: main_channel.id, second_channel: second_channel.id }
            await db.save()

            interaction.reply({ content: `:white_check_mark: تم تعين رومات الداخلية بنجاح`, ephemeral: true })

            let messages = await second_channel.messages.fetch({ limit: 100 })
            await second_channel.bulkDelete(messages)

            sleep(1500)

            let messages2 = await main_channel.messages.fetch({ limit: 100 })
            await main_channel.bulkDelete(messages2)

            let row = new Discord.MessageActionRow()
                .addComponents(
                    new Discord.MessageButton()
                        .setCustomId("join")
                        .setLabel("تسجيل دخول")
                        .setStyle("SUCCESS"),

                    new Discord.MessageButton()
                        .setCustomId("leave")
                        .setLabel("تسجيل خروج")
                        .setStyle("DANGER")
                )

            let embed2 = new Discord.MessageEmbed()
                .setColor("YELLOW")
                .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL() })
                .setDescription(`**__ الرجاء عند دخولك الرحلة الضغط على زر ( تسجيل الدخول <a:reds_true:1086613328744435834>  ) لظهور اسمك بالقائمة . 

الرجاء عند خروج من الرحلة الضغط على زر ( تسجيل خروج <a:reds_false:1086613399804313651>  ) لأخفاء اسمك من القائمة . 

ملاحظة هامة <a:pp823:1078138886435373159>: الرجاء عدم التلاعب بالزر والالتزام 
في حال عدم الالتزام يتم محاسبتك من قبل الإدارة . __**`)
                .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() })
                .setTimestamp()

            await main_channel.send({ embeds: [embed2], components: [row] })

            sleep(3000)

            let embed = new Discord.MessageEmbed()
                .setColor("YELLOW")
                .setAuthor({ name: "قائمة المباشرين في الداخلية", iconURL: interaction.guild.iconURL() })
                .setDescription("None")
                .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() })
                .setTimestamp()

            await second_channel.send({ embeds: [embed] }).then(msg => {
                setInterval(async function () {
                    var db2 = await guildBase.findOne({ guild: interaction.guild.id })

                    var m = "";

                    db2.joins.forEach((user, i) => {
                        let check = interaction.guild.members.cache.get(user)
                        if (!check) return

                        m += `**${i + 1}— ${check} <a:reds_true:1086613328744435834>**\n`
                    })

                    embed.setDescription(`${db2.joins.length <= 0 ? "None" : m}`)
                    sleep(2000)
                    await msg.edit({ embeds: [embed] })
                }, 60000)
            }).catch(() => 0)
        }
    }
};
