const guildBase = require('../../Models/guildBase'), ms = require("ms")
const { checkStore } = require("../../functions");

module.exports = {
    name: `add-new-theft`,
    description: "لإضافة سرقة جديدة",
    default_member_permissions: "0x0000000000000008",
    options: [
        {
            name: "name",
            description: "أرفق اسم السرقة المُستخدم في الامر",
            required: true,
            type: "STRING"
        },
        {
            name: "role",
            description: "الرتبة الي تقدر تستخدم هذه السرقة",
            type: "ROLE",
            required: true
        },
        {
            name: "time",
            description: "الوقت المستغرق للسرقة ( 5 دقائق كـحد أقصى )",
            type: "STRING",
            required: true
        },
        {
            name: "tools",
            description: "الادوات المستخدمة للسرقة ( لإضافة اكثر من اداة اكتب , بينهم )",
            type: "STRING",
            required: true
        },
        {
            name: "values",
            description: "الاشياء اللى تجيه بشكل عشوائي بعد السرقة ( لإضافة أكثر من شي اكتب , بينهم )",
            type: "STRING",
            required: true
        }
    ],
    run: async (client, interaction, Discord) => {
        if (interaction.commandName == "add-new-theft") {
            let name = interaction.options.getString("name"),
                time = interaction.options.getString("time"),
                tools = interaction.options.getString("tools"),
                values = interaction.options.getString("values"),
                role = interaction.options.getRole("role");

            if (!ms(time)) return interaction.reply({ content: `تأكد من صحة الوقت الذي تريد إضافته`, ephemeral: true })
            if (ms(time) > 300000) return interaction.reply({ content: `يمكنك تعين الوقت 5 دقائق كـحد أقصى فقط`, ephemeral: true })

            let db = await guildBase.findOne({ guild: interaction.guild.id })
            if (!db) {
                db = new guildBase({ guild: interaction.guild.id })
                await db.save()
            }

            let check = checkStore(db.store, values.split(","))
            if (!check.status) return interaction.reply({
                content: `لا أستطيع ايجاد هذا الغرض \`${check.value}\` داخل المتجر`, ephemeral: true
            })

            let index = db.thefts.findIndex(c => c.name.toLowerCase() == name.toLowerCase())
            if (index != -1) return interaction.reply({
                content: `تم إضافة هذه السرقة من قبل`,
                ephemeral: true
            })

            db.thefts.push({ name: name, time: ms(time), tools: tools, values: values, role: role.id })
            await db.save()

            await interaction.reply({ content: `:white_check_mark: تم إضافة سرقة جديدة بعنوان \`${name}\``, ephemeral: true })
        }
    }
};
