const guildBase = require('../../Models/guildBase')
module.exports = {
  name: `reset-all-jobs`,
  description: "لحذف جميع الوظايف",
  default_member_permissions: "0x0000000000000008",
  run: async (client, interaction, Discord) => {
    if(interaction.commandName == "reset-all-jobs") {
        let db = await guildBase.findOne({ guild: interaction.guild.id })
        if(!db) {
            db = new guildBase({ guild: interaction.guild.id })
            await db.save()
        }

        db.jobs = []
        await db.save()
  
        await interaction.reply({ content: `:white_check_mark: تم حذف جميع الوظايف`, ephemeral: true })
    }
  }
};
