const guildBase = require('../../Models/guildBase')
module.exports = {
  name: `set-staff`,
  description: "للتعديل على اعدادات الادارة",
  default_member_permissions: "0x0000000000000008",
  options: [
    {
      name: "role",
      description: "لتعين رتبة الادارة",
      type: 1,
      options: [
        {
          name: "role",
          type: "ROLE",
          description: "ارفق الرول الذي تريد تعينها للادارة",
          required: true
        }
      ]
    }
  ],
  run: async (client, interaction, Discord) => {
    if(interaction.commandName == "set-staff") {
      let db = await guildBase.findOne({ guild: interaction.guild.id })
      if(!db) {
        db = new guildBase({ guild: interaction.guild.id })
        await db.save()
      }

      if(interaction.options._subcommand == "role") {
        let role = interaction.options.getRole("role")
  
        db.staff["role"] = role.id
        await db.save()
  
        await interaction.reply({ content: `:white_check_mark: تم تعين رتبة الادارة الى ${role}`, ephemeral: true })
      }
    }
  }
};
