const guildBase = require('../../Models/guildBase')
module.exports = {
  name: `delete-reason`,
  description: "لحذف عقوبة من العقوبات",
  default_member_permissions: "0x0000000000000008",
  options: [
    {
        name: "name",
        description: "أرفق اسم العقوبلة الذي تريد حذفها",
        required: true,
        type: "STRING"
    }
  ],
  run: async (client, interaction, Discord) => {
    if(interaction.commandName == "delete-reason") {
        let name = interaction.options.getString("name");

        let db = await guildBase.findOne({ guild: interaction.guild.id })
        if(!db) {
            db = new guildBase({ guild: interaction.guild.id })
            await db.save()
        }

        let index = db.reasons.findIndex(c => c.name.toLowerCase() == name.toLowerCase())
        if(index == -1) return interaction.reply({ content: `لا أستطيع ايجاد هذه العقوبة داخل العقوبات`, ephemeral: true })

        db.reasons.splice(index, 1)
        await db.save()
  
        await interaction.reply({ content: `:white_check_mark: تم حذف عقوبة من العقوبات بعنوان \`${name}\``, ephemeral: true })
    }
  }
};
