const guildBase = require('../../Models/guildBase'), ms = require("ms")
    , Panels = require('../../Models/Panels')
module.exports = {
    name: `remove`,
    description: "لإزالة عضو من التذكرة",
    default_member_permissions: "0x0000000000000008",
    options: [
        {
            name: "target",
            description: "أرفق الشخص الذي تريد إزالته من التذكرة",
            required: true,
            type: "USER"
        }
    ],
    run: async (client, interaction, Discord) => {
        if (interaction.commandName == "remove") {
            let target = interaction.options.getUser("target")
                , topic = interaction.channel.topic?.split("|")
            if (!topic) return interaction.reply({
                ephemeral: true,
                content: `يجب عليك استخدام هذا الامر داخل تذكرة`

            })

            let panel_id = topic[1]?.trim()
            if (!panel_id) return interaction.reply({
                ephemeral: true,
                content: `يجب عليك استخدام هذا الامر داخل تذكرة`
            })

            let db = await Panels.findOne({ guild: interaction.guild.id, messageId: panel_id })
            if (!db) return interaction.reply({
                content: `لا استطيع ايجاد بانل هذه التذكرة ربما تم حذفه`,
                ephemeral: true

            })

            if (db.rolesId.every(role => !interaction.member.roles.cache.has(role)) && !interaction.member.permissions.has("8")) return interaction.reply({
                content: `لا يمكنك استخدام هذا الزر`,
                ephemeral: true
            })

            const permissions = interaction.channel.permissionsFor(target);

            if (permissions.has(Discord.Permissions.FLAGS.VIEW_CHANNEL)) {
                await interaction.channel.permissionOverwrites.edit(target.id, { VIEW_CHANNEL: false });

                await interaction.reply({
                    content: `:white_check_mark: تم إزالة ${target} من التذكرة \`${interaction.channel.name}\``
                })
            } else {
                return interaction.reply({
                    content: `لم يتم إضافة هذا العضو ${target} من قبل`
                })
            }
        }
    }
};
