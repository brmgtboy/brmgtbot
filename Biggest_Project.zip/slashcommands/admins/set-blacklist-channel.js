const guildBase = require('../../Models/guildBase')
module.exports = {
  name: `set-blacklist-channel`,
  description: "لتعين روم البلاك ليست",
  default_member_permissions: "0x0000000000000008",
  options: [
    {
        name: "channel",
        type: "CHANNEL",
        description: `الروم اللى هتروح له رسايل البلاك ليست`,
        required: true,
        channel_types: ["0"]
    }
  ],
  run: async (client, interaction, Discord) => {
    if(interaction.commandName == "set-blacklist-channel") {
      let main_channel = interaction.options.getChannel("channel")

      let db = await guildBase.findOne({ guild: interaction.guild.id })
      if(!db) {
        db = new guildBase({ guild: interaction.guild.id })
        await db.save()
      }

      db.blacklist_channel = main_channel.id
      await db.save()

      interaction.reply({ content: `:white_check_mark: تم تعين روم البلاك ليست بنجاح`, ephemeral: true })
    }
  }
};
