const guildBase = require('../../Models/guildBase')
module.exports = {
  name: `delete-job`,
  description: "لحذف وظيفة من الوظايف",
  default_member_permissions: "0x0000000000000008",
  options: [
    {
        name: "name",
        description: "أرفق اسم الوظيفة الذي تريد حذفها",
        required: true,
        type: "STRING"
    }
  ],
  run: async (client, interaction, Discord) => {
    if(interaction.commandName == "delete-job") {
        let name = interaction.options.getString("name");

        let db = await guildBase.findOne({ guild: interaction.guild.id })
        if(!db) {
            db = new guildBase({ guild: interaction.guild.id })
            await db.save()
        }

        let index = db.jobs.findIndex(c => c.name.toLowerCase() == name.toLowerCase())
        if(index == -1) return interaction.reply({ content: `لا أستطيع ايجاد هذه الوظيفة داخل الوظايف`, ephemeral: true })

        db.jobs.splice(index, 1)
        await db.save()
  
        await interaction.reply({ content: `:white_check_mark: تم حذف وظايفة من الوظايف بعنوان \`${name}\``, ephemeral: true })
    }
  }
};
