//<a:reds_true:1086613328744435834>
const guildBase = require('../../Models/guildBase')
module.exports = {
  name: `reset-police-joins`,
  description: "لإعادة تعين جميع المباشرين",
  default_member_permissions: "0x0000000000000008",
  run: async (client, interaction, Discord) => {
    if (interaction.commandName == "reset-police-joins") {
      let db = await guildBase.findOne({ guild: interaction.guild.id })
      if (!db) {
        db = new guildBase({ guild: interaction.guild.id })
        await db.save()
      }

      db.joins = []
      await db.save()

      interaction.reply({ content: `:white_check_mark: تم إعادة تعين جميع المباشرين بنجاح`, ephemeral: true })
    }
  }
};
