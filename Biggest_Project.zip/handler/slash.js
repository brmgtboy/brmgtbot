const { readdirSync } = require("fs");

module.exports = async (client) => {
    var array = []
    const slashCommands = readdirSync(process.cwd() + '/slashcommands').filter(file => !file.endsWith('.js'))

    for (const folder of slashCommands) {
        const event2 = readdirSync(process.cwd() + `/slashcommands/${folder}`).filter(file => file.endsWith('.js'))

        for (const file of event2) {
            const command = require(`../slashcommands/${folder}/${file}`)

            client.slashCommands.set(command.name, command);

            array.push(command)

            client.on("ready", () => {
                client.application.commands.set(array)
            });
        }
    }

}