const userBase = require('../../Models/userBase')
  , guildBase = require('../../Models/guildBase');

module.exports = {
  name: `نقاطي`,
  run: async (client, message, args, Discord) => {
    let db = await guildBase.findOne({ guild: message.guild.id })
    if (!db) {
      db = new guildBase({ guild: message.guild.id })
      await db.save()
    }

    if (!db.staff["role"]) return message.reply({ content: `**⚠️ - يجب تعين رتبة الإدارة قبل استخدام الامر**` })
    let role2 = message.guild.roles.cache.get(db.staff["role"])
    if (!role2) return message.reply({
      content: `**⚠️ - لن اتمكن من الوصول لهذه الرتبة داخل السيرفر \`${db.staff["role"]}\`**`
    })

    if (!message.member.roles.cache.has(role2.id)) return message.reply({ 
      content: `**⚠️ - هذا الامر مخصص للإدارة فقط**`
    })

    let data = await userBase.findOne({ guild: message.guild.id, user: message.author.id })
    if (!data) {
      data = new userBase({ guild: message.guild.id, user: message.author.id })
      await db.save()
    }

    data = data.points
    let total = parseInt(data.others + data.gmc + data.join_game + data.start_game + data.tf3el + data.claim)

    let embed = new Discord.MessageEmbed()
      .setColor("YELLOW")
      .setAuthor({ name: "كشف نقاط", iconURL: message.guild.iconURL() })
      .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
      .setThumbnail(message.guild.iconURL())
      .setTimestamp()
      .setDescription(`**__نقاط الإداري ${message.author}__

__التكتات | ${data.claim}__

__التفعيل | ${data.tf3el}__

__فتح الاقيام | ${data.start_game}__

__دخول الاقيام | ${data.join_game}__

__الرقابة | ${data.gmc}__

__الاضافية | ${data.others}__

__الاجمالي | ${total}__**`)

    await message.reply({
      embeds: [embed]
    })
  }
};
