const guildBase = require('../../Models/guildBase')

module.exports = {
  name: `افتح-قيم`,
  aliases: ["فتح-قيم", "بدا-رحلة", "بدأ-رحلة", "ابدا-رحلة"],
  run: async (client, message, args, Discord) => {
    let db = await guildBase.findOne({ guild: message.guild.id })
    if (!db) {
      db = new guildBase({ guild: message.guild.id })
      await db.save();
    }

    if (!db.staff["role"]) return message.reply({ content: `**⚠️ - يجب تعين رتبة الإدارة قبل استخدام الامر**` })
    let role2 = message.guild.roles.cache.get(db.staff["role"])
    if (!role2) return message.reply({ 
      content: `**⚠️ - لن اتمكن من الوصول لهذه الرتبة داخل السيرفر \`${db.staff["role"]}\`**` 
    })

    if (!message.member.roles.cache.has(role2.id)) return message.reply({ 
      content: `**⚠️ - هذا الامر مخصص للإدارة فقط**`
    })

    if (!db?.channels.main_game || !db?.channels.second_game) return message.reply({
      content: `**⚠️ - يجب تعين رومات الاقيام قبل استخدام الامر**`
    })

    let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setCustomId(`startgame_${message.author.id}`)
        .setLabel("بدء")
        .setStyle("SECONDARY")
    )

    let msg = await message.reply({
      content: `**لبدأ الاستبيان أضغط على الزر بالاسفل**`,
      components: [row]
    })

    const collector = msg.createMessageComponentCollector({ componentType: 'BUTTON', time: 20000 });
    collector.on('collect', async i => {
      if (i.user.id != message.author.id) return i.reply({
        content: `**❌ - لبدأ الاستبيان أضغط على الزر بالاسفل**`,
        ephemeral: true
      })

      if (i.customId.startsWith("startgame_")) {
        const modal = new Discord.Modal()
          .setTitle('أستبيان بدء القيم')
          .setCustomId('start_gamex');

        const owner = new Discord.TextInputComponent()
          .setCustomId('owner')
          .setLabel("أيدي القائد")
          .setStyle('SHORT');

        const co_owner = new Discord.TextInputComponent()
          .setCustomId('co_owner')
          .setLabel("أيدي مساعد القائد")
          .setStyle('SHORT');

        const time = new Discord.TextInputComponent()
          .setCustomId('time')
          .setLabel("وقت الرحلة")
          .setStyle('SHORT');

        const row1 = new Discord.MessageActionRow().addComponents(owner)
          , row2 = new Discord.MessageActionRow().addComponents(co_owner)
          , row3 = new Discord.MessageActionRow().addComponents(time);

        modal.addComponents(row1, row2, row3);

        await i.showModal(modal);
      } else return;
    })

    collector.on("end", () => {
      if (msg.components.length <= 0) return;

      msg.edit({ content: "**❌ - أنتهى الوقت**", components: [] })
    })
  }
};
