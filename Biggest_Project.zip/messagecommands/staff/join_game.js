const guildBase = require('../../Models/guildBase')
  , { addpoints } = require("../../functions");

module.exports = {
  name: `دخول-قيم`,
  aliases: ["حضور-قيم", "حضور-رحلة", "دخول-رحلة"],
  run: async (client, message, args, Discord) => {
    let db = await guildBase.findOne({ guild: message.guild.id })
    if (!db) {
      db = new guildBase({ guild: message.guild.id })
      await db.save();
    }

    if (!db.staff["role"]) return message.reply({ content: `**⚠️ - يجب تعين رتبة الإدارة قبل استخدام الامر**` })
    let role2 = message.guild.roles.cache.get(db.staff["role"])
    if (!role2) return message.reply({
      content: `**⚠️ - لن اتمكن من الوصول لهذه الرتبة داخل السيرفر \`${db.staff["role"]}\`**`
    })

    if (!message.member.roles.cache.has(role2.id)) return message.reply({
      content: `**⚠️ - هذا الامر مخصص للإدارة فقط**`
    })

    addpoints(message.guild.id, message.author.id, "join_game", 1)

    let hehea = new Discord.MessageEmbed()
      .setColor("YELLOW")
      .setAuthor({ name: message.guild.name, iconURL: message.guild.iconURL() })
      .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
      .setThumbnail(message.guild.iconURL())
      .setTimestamp()
      .setDescription(`** ✅ - تم اضافة نقطة ادارية 

| نوع النقطة :  دخول الرحلة

| الاداري : ${message.author}**`)

    await message.reply({ embeds: [hehea] })
  }
};
