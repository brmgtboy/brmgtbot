const guildBase = require('../../Models/guildBase')
  , { addpoints } = require("../../functions");

module.exports = {
  name: `اضافة-نقاط`,
  aliases: ["إضافة-نقاط"],
  run: async (client, message, args, Discord) => {
    let db = await guildBase.findOne({ guild: message.guild.id })
    if (!db) {
      db = new guildBase({ guild: message.guild.id })
      await db.save()
    }

    if (!db.staff_points) return message.reply({ content: `لم يتم تعين رتبة المسؤولين عن النقاط حتى الان` })

    let role = message.guild.roles.cache.get(db.staff_points)
    if (!role) return message.reply({ content: `لا استطيع ايجاد هذه الرول \`${db.staff_points}\` داخل هذا الخادم ` })

    if (!message.member.roles.cache.has(role.id)) return message.reply({ content: `هذا الامر متاح لمسؤولين النقاط فقط` })

    let user = message.mentions.members.first()
    if (!user) return message.reply({
      content: `يجب عليك تحديد الاداري الذي تريد اضافة نقاط له`
    })

    let amount = args[1]
    if (!amount || isNaN(amount)) return message.reply({ content: `يجب عليك تحديد كمية النقاط الذي تريد اضافتها له` })

    if (user.user.bot) return message.reply({ content: `لا يمكنك إضافة نقاط لهذا الشخص ${user} لانه بوت` })

    if (!db.staff["role"]) return message.reply({ content: `لم يتم تعين رتبة الادارة حتى الان` })
    let role2 = message.guild.roles.cache.get(db.staff["role"])
    if (!role2) return message.reply({ content: `لا استطيع ايجاد هذه الرول \`${db.staff["role"]}\` داخل هذا الخادم ` })

    if (!user.roles.cache.has(role2.id)) return message.reply({ content: `لا يمكنك إضافة نقاط لهذا الشخص ${user} لانه ليس اداري` })

    addpoints(message.guild.id, user.user.id, "others", parseInt(amount))

    let hehea = new Discord.MessageEmbed()
      .setColor("YELLOW")
      .setAuthor({ name: message.guild.name, iconURL: message.guild.iconURL() })
      .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
      .setThumbnail(message.guild.iconURL())
      .setTimestamp()
      .setDescription(`** ✅ - تم اضافة نقطة ادارية

| الاداري : ${user}

| بواسطة : ${message.author}**`)

    await message.reply({ embeds: [hehea] })
  }
};
