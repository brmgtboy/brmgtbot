const guildBase = require('../../Models/guildBase')
  , userBase = require("../../Models/userBase");

module.exports = {
  name: `اضافة-مخالفة`,
  aliases: ["إضافة-مخالفة"],
  run: async (client, message, args, Discord) => {
    let db = await guildBase.findOne({ guild: message.guild.id })
    if (!db) {
      db = new guildBase({ guild: message.guild.id })
      await db.save()
    }

    if (!db.police) return message.reply({ content: `**⚠️ - لم يتم تعين رتبة المسؤولين عن الشرطة حتى الان**` })

    let role = message.guild.roles.cache.get(db.police)
    if (!role) return message.reply({ content: `**⚠️ - لا استطيع ايجاد هذه الرول \`${db.police}\` داخل هذا الخادم **` })

    if (!message.member.roles.cache.has(role.id)) return message.reply({ content: `هذا الامر متاح لمسؤولين الشرطة فقط**` })

    let user = message.mentions.members.first()
    if (!user) return message.reply({
      content: `**⚠️ - يجب عليك تحديد الشخص الذي تريد اضافة مخالفه له`
    })

    if (user.user.bot) return message.reply({ content: `**⚠️ - لا يمكنك إضافة مخالفة لهذا الشخص ${user} لانه بوت**` })

    if (db.mo5alfat.length <= 0) return message.reply({ content: `**⚠️ - لا يوجد مخالفات تمت اضافتها حتى الان**` })

    let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setCustomId(`m5alfa_${message.author.id}_1`)
        .setLabel("الشخصية الاولى")
        .setStyle("SECONDARY"),

      new Discord.MessageButton()
        .setCustomId(`m5alfa_${message.author.id}_2`)
        .setLabel("الشخصية الثانية")
        .setStyle("SECONDARY")
    )

    let msg = await message.reply({
      content: `**قم بإختيار الشخصية الذي تريد إضافة مخالفة لها**`,
      components: [row]
    })

    const collector = msg.createMessageComponentCollector({ componentType: 'BUTTON', time: 20000 });
    collector.on('collect', async i => {
      if (i.user.id != message.author.id) return i.reply({
        content: `**⚠️ - ليس لديك صلاحيات لاستخدام هذا الاختيار**`,
        ephemeral: true
      })

      if (i.customId.startsWith("m5alfa")) {
        let data = await userBase.findOne({ guild: message.guild.id, user: user.id })
        if (!data) {
          data = new userBase({ guild: message.guild.id, user: user.id })
          await data.save()
        }

        i.customId.endsWith("1") ? data = data.c1 : data = db.c2

        await msg.delete().catch(() => 0)

        let row2 = new Discord.MessageActionRow()
          .addComponents(
            new Discord.MessageSelectMenu()
              .setCustomId(`types_mo5alfat`)
              .setPlaceholder('حدد نوع المخالفة')
              .setMinValues(1)
              .setMaxValues(1)
              .addOptions(db.mo5alfat.map(type => ({ label: `${type.name}`, value: `${type.name}`, description: `Price: ${type.price}` })))
          );

        let msg2 = await message.reply({ components: [row2] })
        const collector = msg2.createMessageComponentCollector({ componentType: 'SELECT_MENU', time: 20000 });
        collector.on('collect', async i2 => {
          if (i2.user.id != message.author.id) return i2.reply({
            content: `**⚠️ - ليس لديك صلاحيات لاستخدام هذا الاختيار**`,
            ephemeral: true
          })

          if (i2.customId.startsWith("types_mo5alfat")) {
            let value = i2.values[0]

            let index = db.mo5alfat.findIndex(c => c.name.toLowerCase() == value.toLowerCase())
            if (index == -1) return msg2.edit({ components: [], content: `**⚠️ - لا أستطيع ايجاد هذه المخالفة من المخالفات ، ربما تم حذفها**` })

            data.m5alfat.push({ type: db.mo5alfat[index].name, price: parseInt(db.mo5alfat[index].price) })
            await userBase.updateOne({ guild: message.guild.id, user: user.id },
              {
                $set: {
                  [`${i.customId.endsWith("1") ? "c1" : "c2"}.m5alfat`]: data.m5alfat
                }
              }
            );

            let embed = new Discord.MessageEmbed()
            .setColor("YELLOW")
            .setThumbnail(message.guild.iconURL())
            .setTimestamp()
            .setAuthor({ name: message.guild.name, iconURL: message.guild.iconURL() })
            .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
            .setDescription(`**✅ - تم اصدار المخالفة بنجاح 

| المواطن : ${user}

| مسؤول المخالفة : ${message.author}

| المخالفة : \`${db.mo5alfat[index].name}\`

| سعر المخالفة : __${parseInt(db.mo5alfat[index].price)}__

| الشخصية : ${i.customId.endsWith("1") ? "الاولى" : "الثانية"}**`)

            msg2.edit({
              content: null,
              embeds: [embed],
              components: []
            })

            user.send({
              content: `** عزيزي المواطن : ${user}

✅ - تم قيد مخالفة مرورية 

| المخالفة : \`${db.mo5alfat[index].name}\`

| مبلغ المخالفة : __${parseInt(db.mo5alfat[index].price)}_

⚠️ - في حال عدم السداد يتم إيقاف خدماتك 

👮‍♂️ - تم اصدارها واعتمادها من قبل وزارة الداخلية **`
            }).catch(() => 0)
          }
        })
      } else return;
    })
  }
};
