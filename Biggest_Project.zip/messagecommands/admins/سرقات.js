const userBase = require('../../Models/guildBase');

module.exports = {
  name: `سرقات`,
  run: async (client, message, args, Discord) => {
    if (!message.member.permissions.has("8")) return;

    let data = await userBase.findOne({ guild: message.guild.id })
    if (!data) {
      data = new userBase({ guild: message.guild.id })
      await data.save()
    }

    if (data.thefts.length <= 0) return message.reply({ content: `**⚠️ - لا يوجد سرقات تمت اضافتها حتى الان**` })

    let embed = new Discord.MessageEmbed()
      .setColor("YELLOW")
      .setAuthor({ name: `كشف السرقات`, iconURL: message.guild.iconURL() })
      .setThumbnail(message.guild.iconURL())
      .setTimestamp()

    data.thefts.forEach(ttt => {
      embed.addFields({ name: `سرقة ${ttt.name}`, value: `${ttt.tools.split(",").map(c => `- ${c}`).join("\n")}`, inline: true })
    })

    message.reply({ embeds: [embed] })
  }
};
