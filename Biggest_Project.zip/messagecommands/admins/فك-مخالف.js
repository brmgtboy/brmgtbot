const guildBase = require('../../Models/guildBase')
  , Blacklisted = require('../../Models/blacklisted')
  , { sleep } = require("../../functions");

module.exports = {
  name: `فك-مخالف`,
  run: async (client, message, args, Discord) => {
    let db = await guildBase.findOne({ guild: message.guild.id })
    if (!db) {
      db = new guildBase({ guild: message.guild.id })
      await db.save()
    }

    if (!db.blacklist) return message.reply({ content: `**⚠️ - لم يتم تعين رتبة المسؤولين عن البلاك ليست حتى الان**` })

    let role = message.guild.roles.cache.get(db.blacklist)
    if (!role) return message.reply({ content: `**⚠️ - لا استطيع ايجاد هذه الرول \`${db.poblacklistlice}\` داخل هذا الخادم **` })

    if (!message.member.roles.cache.has(role.id)) return message.reply({ content: `هذا الامر متاح لمسؤولين بلاك ليست فقط**` })

    let user = message.mentions.members.first()
    if (!user) return message.reply({
      content: `**⚠️ - يجب عليك تحديد الشخص الذي تريد فك عقابه**`
    })

    if (user.user.bot) return message.reply({ content: `**⚠️ - لا يمكنك فك عقاب هذا الشخص ${user} لانه بوت**` })

    let blacklist_data = await Blacklisted.findOne({ guild: message.guild.id, user: user.user.id })
    if (!blacklist_data) return message.reply({ content: `**⚠️ - ${user} ليس لديه عقوبات حتى الان**` })

    user.roles.cache.filter(role => role.name != "@everyone").map(role => role.id).forEach(role => {
      sleep(1000)
      user.roles.remove(role).catch(() => 0)
    })
    sleep(3000)

    blacklist_data.roles.forEach(role => {
      sleep(1000)
      user.roles.add(role).catch(() => 0)
    })

    await Blacklisted.deleteMany({ guild: message.guild.id, user: user.user.id })

    await message.reply({ content: `**:white_check_mark: تم فك المخالفة بنجاح

العضو : ${user}

بواسطة : ${message.author}**` })

    let log_channel = message.guild.channels.cache.get(db.blacklist_channel)
    if (log_channel) {
      let embed = new Discord.MessageEmbed()
        .setColor("YELLOW")
        .setAuthor({ name: "فك مخالفة جديدة", iconURL: message.guild.iconURL() })
        .setThumbnail(message.guild.iconURL())
        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
        .setTimestamp()
        .setDescription(`**الإداري المسؤول عن فك السجن:** ${message.author}\n\n**العضو المخالف:** ${user}`)

      await log_channel?.send({ embeds: [embed] })
    }
  }
};
