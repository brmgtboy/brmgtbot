module.exports = {
  name: `embed`,
  aliases: ["em", "say-embed"],
  run: async (client, message, args, Discord) => {
    if (!message.member.permissions.has("8")) return;

    let channel = message.mentions.channels.first()
    if (!channel) return message.reply({
      content: `**⚠️ - يجب عليك تحديد الروم الذي تريد ارسال الرسالة لها**`
    })

    let msg = message.content.split(" ").slice(2).join(" ")
    if (!msg) return message.reply({
      content: `**⚠️ - يجب عليك تحديد الرسالة الذي تريد ارسالها**`
    })

    let embed = new Discord.MessageEmbed()
      .setAuthor({ name: message.guild.name, iconURL: message.guild.iconURL() })
      .setDescription(`${msg}`)
      .setTimestamp()
      .setThumbnail(message.guild.iconURL())
      .setColor("YELLOW")

    let image = message.attachments.first()
    if (image) {
      embed.setImage(image.proxyURL)
    }

    channel?.send({ embeds: [embed] })
      .then(async () => await message.react("✅"))
      .catch(async () => await message.react("❌"))
  }
};
