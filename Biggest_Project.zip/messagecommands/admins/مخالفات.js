const guildBase = require('../../Models/guildBase');

module.exports = {
  name: `مخالفات`,
  run: async (client, message, args, Discord) => {
    let data = await guildBase.findOne({ guild: message.guild.id })
    if (!data) {
      data = new guildBase({ guild: message.guild.id })
      await data.save()
    }

    if (!data.mo_listadmin) return message.reply({ content: `**⚠️ - لم يتم تعين رتبة المسؤولين عن الليست حتى الان**` })

    let role = message.guild.roles.cache.get(db.mo_listadmin)
    if (!role) return message.reply({ content: `**⚠️ - لا استطيع ايجاد هذه الرول \`${db.mo_listadmin}\` داخل هذا الخادم **` })

    if (!message.member.roles.cache.has(role.id)) return message.reply({ content: `**⚠️ - هذا الامر متاح لمسؤولين الليست فقط**` })

    if (data.mo5alfat.length <= 0) return message.reply({ content: `**⚠️ - لا يوجد مخالفات تمت اضافتها حتى الان**` })

    let embed = new Discord.MessageEmbed()
      .setColor("YELLOW")
      .setAuthor({ name: `مخالفات الشرطة`, iconURL: message.guild.iconURL() })
      .setThumbnail(message.guild.iconURL())
      .setTimestamp()

    data.mo5alfat.forEach(ttt => {
      embed.addFields({ name: `${ttt.name}`, value: `- ${ttt.price}`, inline: true })
    })

    message.reply({ embeds: [embed] })
  }
};
