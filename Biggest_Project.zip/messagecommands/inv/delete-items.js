const guildBase = require('../../Models/guildBase')

module.exports = {
  name: `delete-items`,
  run: async (client, message, args, Discord) => {
    let datad = await guildBase.findOne({ guild: message.guild.id })
    if (!datad) {
      datad = new guildBase({ guild: message.guild.id })
      await datad.save()
    }

    if (!datad.invbank) return message.reply({ 
      content: `**⚠️ - يجب تعين رتبة مسؤولين الحقيبة والبنك قبل استخدام الامر**`
    })
    let role2 = message.guild.roles.cache.get(datad.invbank)
    if (!role2) return message.reply({ 
      content: `**⚠️ - لم اتمكن من الوصول لهذه الرتبة داخل السيرفر \`${db.invbank}\`**`
    })

    if (!message.member.roles.cache.has(role2.id)) return message.reply({ 
      content: `**⚠️ - هذا الامر مخصص لمسؤولين الحقيبة والبنك فقط**`
    })

    let type = args[0]
    if (!type) return message.reply({
      content: `**⚠️ - يجب عليك تحديد الغرض الذي تريد إزالته**`
    })

    let data = await guildBase.findOne({ guild: message.guild.id })
    if (!data) {
      data = new guildBase({ guild: message.guild.id })
      await data.save()
    }

    let index = data.store.findIndex(c => c.name.toLowerCase() == type.toLowerCase())
    if (index == -1) return message.reply({
      content: `**⚠️ - لن اتمكن من الحصول على هذا الغرض داخل المتجر**`
    })

    data.store.splice(index, 1)
    await data.save()

    await message.reply({
      content: `**:white_check_mark: - تم إزالة الغرض من داخل المتجر بنجاح

الغرض : \`${type.toLowerCase()}\`

بواسطة : ${message.author}**`
    })
  }
};
