const guildBase = require('../../Models/guildBase')

module.exports = {
  name: `add-store`,
  run: async (client, message, args, Discord) => {
    let db = await guildBase.findOne({ guild: message.guild.id })
    if (!db) {
      db = new guildBase({ guild: message.guild.id })
      await db.save()
    }

    if (!db.invbank) return message.reply({
      content: `**⚠️ - يجب تعين رتبة مسؤولين الحقيبة والبنك قبل استخدام الامر**`
    })
    let role2 = message.guild.roles.cache.get(db.invbank)
    if (!role2) return message.reply({
      content: `**⚠️ - لم اتمكن من الوصول لهذه الرتبة داخل السيرفر \`${db.invbank}\`**`
    })

    if (!message.member.roles.cache.has(role2.id)) return message.reply({
      content: `**⚠️ - هذا الامر مخصص لمسؤولين الحقيبة والبنك فقط**`
    })

    let price = args[0]
    if (!price || isNaN(price)) return message.reply({
      content: `**⚠️ - يجب تحديد سعر الغرض الذي تريد اضافته**`
    })

    let type = message.content.split(" ").slice(2).join(" ")
    if (!type) return message.reply({
      content: `**⚠️ - يجب تحديد الغرض الذي تريد اضافته**`
    })

    let data = await guildBase.findOne({ guild: message.guild.id })
    if (!data) {
      data = new guildBase({ guild: message.guild.id })
      await data.save()
    }

    let index = data.store.findIndex(c => c.name.toLowerCase() == type.toLowerCase())
    if (index == -1) {
      data.store.push({ name: type.toLowerCase(), price: parseInt(price) })
    } else {
      data.store[index] = { name: type.toLowerCase(), price: Number(price) }
    }
    await data.save()

    await message.reply({
      content: `** ✅ - تم إضافة المنتج الى المتجر بنجاح 

| المنتج : ${type}

| سعر المنتج :  ${parseInt(price)}**`
    })
  }
};
