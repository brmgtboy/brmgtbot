const userBase = require('../../Models/userBase')
module.exports = {
  name: `use`,
  run: async (client, message, args, Discord) => {
    let amount = args[0]
    if (!amount || isNaN(amount)) return message.reply({
      content: `**⚠️ - يجب عليك تحديد الكمية الذي تريد استخدامه**`
    })

    let type = args[1]
    if (!type) return message.reply({
      content: `**⚠️ - يجب عليك تحديد الشي الذي تريد استخدامه**`
    })

    let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setCustomId(`use_${message.author.id}_1`)
        .setLabel("الشخصية الاولى")
        .setStyle("SECONDARY"),

      new Discord.MessageButton()
        .setCustomId(`use_${message.author.id}_2`)
        .setLabel("الشخصية الثانية")
        .setStyle("SECONDARY")
    )

    let msg = await message.reply({
      content: `**قم بإختيار الشخصية الذي تريد السحب منها**`,
      components: [row]
    })

    const collector = msg.createMessageComponentCollector({ componentType: 'BUTTON', time: 20000 });
    collector.on('collect', async i => {
      if (i.user.id != message.author.id) return i.reply({
        content: `**⚠️ - ليس لديك صلاحيات لاستخدام هذا الاختيار**`,
        ephemeral: true
      })

      if (i.customId.startsWith("use")) {
        let data = await userBase.findOne({ guild: message.guild.id, user: message.author.id })
        if (!data) {
          data = new userBase({ guild: message.guild.id, user: message.author.id })
          await data.save()
        }

        i.customId.endsWith("1") ? data = data.c1 : data = data.c2

        let index = data.inv.findIndex(c => c.name.toLowerCase() == type.toLowerCase())
        if (index == -1) return msg.edit({
          content: `**⚠️ - لا أستطيع ايجاد هذا الغرض داخل شخصيتك ${i.customId.endsWith("1") ? "الاولى" : "الثانية"}**`,
          components: []
        })

        if (Number(data.inv[index].count) < parseInt(amount)) return msg.edit({
          content: `**⚠️ - كمية الغرض الذي تمكلها بشخصيتك ${i.customId.endsWith("1") ? "الاولى" : "الثانية"} أقل من الكمية الذي تريد استخدامها**`,
          components: []
        })

        if (Number(data.inv[index].count) == parseInt(amount)) {
          data.inv.splice(index, 1)
        } else {
          data.inv[index] = { name: type.toLowerCase(), count: parseInt(Number(data.inv[index].count) - Number(amount)) }
        }

        await userBase.updateOne({ guild: message.guild.id, user: message.author.id },
          {
            $set: {
              [`${i.customId.endsWith("1") ? "c1" : "c2"}.inv`]: data.inv
            }
          }
        );

        msg.edit({
          content: `** ✅ - تم أستخدام المنتج بنجاح **`,
          components: []
        })
      } else return;
    })
  }
};
