const userBase = require('../../Models/userBase'), guildBase = require('../../Models/guildBase');
module.exports = {
  name: `انشاء-هوية`,
  aliases: ["انشاء-هويه"],
  run: async (client, message, args, Discord) => {
    let db = await guildBase.findOne({ guild: message.guild.id })
    if (!db) {
      db = new guildBase({ guild: message.guild.id })
      await db.save();
    }

    let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setCustomId(`createId_${message.author.id}_1`)
        .setLabel("الشخصية الاولى")
        .setStyle("SECONDARY"),

      new Discord.MessageButton()
        .setCustomId(`createId_${message.author.id}_2`)
        .setLabel("الشخصية الثانية")
        .setStyle("SECONDARY")
    )

    let msg = await message.reply({
      content: `**قم بإختيار الشخصية الذي تريد انشاء هوية لها**`,
      components: [row]
    })

    const collector = msg.createMessageComponentCollector({ componentType: 'BUTTON', time: 20000 });
    collector.on('collect', async i => {
      if (i.user.id != message.author.id) return i.reply({
        content: `**⚠️ - ليس لديك صلاحيات لاستخدام هذا الاختيار**`,
        ephemeral: true
      })

      if (i.customId.startsWith("createId")) {
        let data = await userBase.findOne({ guild: message.guild.id, user: message.author.id })
        if (!data) {
          data = new userBase({ guild: message.guild.id, user: message.author.id })
          await data.save()
        }

        i.customId.endsWith("1") ? data = data.c1 : data = data.c2

        if (data.id && Object.keys(data.id)?.length > 0) return msg.edit({
          content: `**⚠️ - عذرا ولكن هذه الشخصية تملك هوية بالفعل**`,
          components: []
        })

        await msg.edit({ 
          components: [], 
          content: `**:white_check_mark: - تم إرسال الاستبيان على الخاص ، اذا لم يصلك الاستبيان تأكد من فتح الخاص وحاول مرة آخرى**`
        })

        message.author.send({ content: `**اسمك :**\n**__لديك 20 ثانية__ ⚠️**` }).then((m1) => {
          m1.channel.awaitMessages({ max: 1, time: 20000, errors: ['time'] })
            .then(collected => {
              var q1 = collected.first().content

              m1.edit({ content: `**عمرك :**\n**__لديك 20 ثانية__ ⚠️**` }).then((m2) => {
                m2.channel.awaitMessages({ max: 1, time: 20000, errors: ['time'] })
                  .then(collected => {
                    var q2 = collected.first().content

                    m2.edit({ content: `**مكان الميلاد :**\n**__لديك 20 ثانية__ ⚠️**` }).then((m3) => {
                      m3.channel.awaitMessages({ max: 1, time: 20000, errors: ['time'] })
                        .then(collected => {
                          var q3 = collected.first().content

                          m3.edit({ content: `**نوع الشخصية :**\n**__لديك 20 ثانية__ ⚠️**` }).then((m4) => {
                            m4.channel.awaitMessages({ max: 1, time: 20000, errors: ['time'] })
                              .then(collected => {
                                var q4 = collected.first().content

                                m4.edit({ content: `**وظيفتك :**\n**__لديك 20 ثانية__ ⚠️**` }).then((m5) => {
                                  m5.channel.awaitMessages({ max: 1, time: 20000, errors: ['time'] })
                                    .then(async collected => {
                                      var q5 = collected.first().content

                                      let embed = new Discord.MessageEmbed()
                                        .setColor("YELLOW")
                                        .setAuthor({ name: message.guild.name, iconURL: message.guild.iconURL() })
                                        .setTimestamp()
                                        .setThumbnail(message.guild.iconURL())
                                        .setDescription(`**__ عزيزي المواطن : ${message.author}

تم اصدار هويتك الوطنية من قبل وزارة الداخلية
                                                
شاكرين لك ✅ __**`)

                                      m5.edit({ embeds: [embed], content: null })

                                      data.id = { name: q1, age: q2, place: q3, type: q4, job: q5 }
                                      await userBase.updateOne({ guild: message.guild.id, user: message.author.id },
                                        {
                                          $set: {
                                            [`${i.customId.endsWith("1") ? "c1" : "c2"}`]: data
                                          }
                                        }
                                      );
                                    })
                                    .catch(() => { m1.edit({ content: "⚠️ أنتهى الوقت" }) });
                                }).catch(() => 0)
                              })
                              .catch(() => { m1.edit({ content: "⚠️ أنتهى الوقت" }) });
                          }).catch(() => 0)
                        })
                        .catch(() => { m1.edit({ content: "⚠️ أنتهى الوقت" }) });
                    }).catch(() => 0)
                  })
                  .catch(() => { m1.edit({ content: "⚠️ أنتهى الوقت" }) });
              }).catch(() => 0)
            })
            .catch(() => { m1.edit({ content: "⚠️ أنتهى الوقت" }) });
        }).catch(() => 0)
      } else return;
    })
  }
};
