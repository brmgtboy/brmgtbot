const userBase = require('../../Models/userBase')
module.exports = {
  name: `سداد`,
  aliases: ["سداد-مخالفة"],
  run: async (client, message, args, Discord) => {
    let type = message.content.split(" ").slice(1).join(" ")
    if (!type) return message.reply({
      content: `**⚠️ - يجب عليك ذكر اسم المخالفة الذي تريد تسديدها**`
    })

    let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setCustomId(`endmo5alfa_${message.author.id}_1`)
        .setLabel("الشخصية الاولى")
        .setStyle("SECONDARY"),

      new Discord.MessageButton()
        .setCustomId(`endmo5alfa_${message.author.id}_2`)
        .setLabel("الشخصية الثانية")
        .setStyle("SECONDARY")
    )

    let msg = await message.reply({
      content: `**قم بإختيار الشخصية الذي تريد سداد عنها**`,
      components: [row]
    })

    const collector = msg.createMessageComponentCollector({ componentType: 'BUTTON', time: 20000 });
    collector.on('collect', async i => {
      if (i.user.id != message.author.id) return i.reply({
        content: `**⚠️ - ليس لديك صلاحيات لاستخدام هذا الاختيار**`,
        ephemeral: true
      })

      if (i.customId.startsWith("endmo5alfa")) {
        let data = await userBase.findOne({ guild: message.guild.id, user: message.author.id })
        if (!data) {
          data = new userBase({ guild: message.guild.id, user: message.author.id })
          await data.save()
        }

        i.customId.endsWith("1") ? data = data.c1 : data = data.c2

        if (data.m5alfat.length <= 0) return msg.edit({
          content: `**⚠️ - عذراً ولكن الشخصية ${i.customId.endsWith("1") ? "الاولى" : "الثانية"} لا تملك أي نوع من المخالفات**`,
          components: []
        })

        let index = data.m5alfat.findIndex(c => c.type.toLowerCase() == type.toLowerCase())
        if (index == -1) return msg.edit({
          content: `**⚠️ - عذراً لكن لا استطيع الحصول على مخالفة بهذا الاسم في مخالفات شخصيتك ${i.customId.endsWith("1") ? "الاولى" : "الثانية"}**`,
          components: []
        })

        let mo5alfa = data.m5alfat[index]

        if (parseInt(data.bank) < parseInt(mo5alfa.price)) return msg.edit({
          content: `**⚠️ - عذرا ولكن رصيدك البنكي في شخصيتك ${i.customId.endsWith("1") ? "الاولى" : "الثانية"} أقل من مبلغ المخالفة**`,
          components: []
        })

        data.bank = parseInt(data.bank - Number(mo5alfa.price))
        data.m5alfat.splice(index, 1)

        await userBase.updateOne({ guild: message.guild.id, user: message.author.id },
          {
            $set: {
              [`${i.customId.endsWith("1") ? "c1" : "c2"}`]: data
            }
          }
        );

        let embed = new Discord.MessageEmbed()
        .setColor("YELLOW")
        .setThumbnail(message.guild.iconURL())
        .setTimestamp()
        .setAuthor({ name: message.guild.name, iconURL: message.guild.iconURL() })
        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
        .setDescription(`** عزيزي المواطن : ${message.author}

تم سداد المخالفة بنجاح - ✅ 

| المخالفة : ${type}

| سعر المخالفة : __${mo5alfa.price}__**`)

        msg.edit({
          embeds: [embed],
          content: null,
          components: []
        })
      }
    })
  }
};
