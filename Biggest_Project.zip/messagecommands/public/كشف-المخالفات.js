const userBase = require('../../Models/userBase')
module.exports = {
  name: `كشف-المخالفات`,
  aliases: ["مخالفاتي", "كشف-مخالفات"],
  run: async (client, message, args, Discord) => {
    let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setCustomId(`checkm5alfa_${message.author.id}_1`)
        .setLabel("الشخصية الاولى")
        .setStyle("SECONDARY"),

      new Discord.MessageButton()
        .setCustomId(`checkm5alfa_${message.author.id}_2`)
        .setLabel("الشخصية الثانية")
        .setStyle("SECONDARY")
    )

    let msg = await message.reply({
      content: `**قم بإختيار الشخصية الذي تريد الاستعلام عنها**`,
      components: [row]
    })

    const collector = msg.createMessageComponentCollector({ componentType: 'BUTTON', time: 20000 });
    collector.on('collect', async i => {
      if (i.user.id != message.author.id) return i.reply({
        content: `**⚠️ - ليس لديك صلاحيات لاستخدام هذا الاختيار**`,
        ephemeral: true
      })

      if (i.customId.startsWith("checkm5alfa")) {
        let data = await userBase.findOne({ guild: message.guild.id, user: message.author.id })
        if (!data) {
          data = new userBase({ guild: message.guild.id, user: message.author.id })
          await data.save()
        }

        i.customId.endsWith("1") ? data = data.c1 : data = data.c2

        if (data.m5alfat.length <= 0) return msg.edit({
          content: `**⚠️ - عذراً ولكن الشخصية ${i.customId.endsWith("1") ? "الاولى" : "الثانية"} لا تملك أي نوع من المخالفات**`,
          components: []
        })

        var msg2 = ""
        data.m5alfat.forEach((mo5alfa, i) => {
          msg2 += `\`#${i + 1}\` | ${mo5alfa.type} : **__${mo5alfa.price}__**\n`
        })

        let embed = new Discord.MessageEmbed()
          .setColor("YELLOW")
          .setAuthor({ name: `كشف مخالفات`, iconURL: message.author.avatarURL() })
          .setThumbnail(message.guild.iconURL())
          .setTimestamp()
          .setDescription(`${msg2}`)

        msg.edit({
          embeds: [embed],
          content: null,
          components: []
        })
      }
    })
  }
};
