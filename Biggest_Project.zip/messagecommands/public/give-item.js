const userBase = require('../../Models/userBase')
module.exports = {
    name: `give-item`,
    run: async (client, message, args, Discord) => {
        let user = message.mentions.users.first()
        if (!user) return message.reply({
            content: `**⚠️ - يجب عليك تحديد الشخص الذي تريد التحويل له**`
        })

        let amount = args[1]
        if (!amount || isNaN(amount)) return message.reply({
            content: `**⚠️ - يجب عليك تحديد الكمية الذي تريد تحويلها**`
        })

        let type = args[2]
        if (!type) return message.reply({
            content: `**⚠️ -يجب عليك تحديد الغرض الذي تريد تحويله**`
        })

        if (user.bot || user.id == message.author.id) return message.reply({
            content: `**⚠️ - عذراً ، لكنك لا تستطيع تحويل أغراض الى ${user}**`
        })

        let row = new Discord.MessageActionRow().addComponents(
            new Discord.MessageButton()
                .setCustomId(`giveitem_${message.author.id}_1`)
                .setLabel("الشخصية الاولى")
                .setStyle("SECONDARY"),

            new Discord.MessageButton()
                .setCustomId(`giveitem_${message.author.id}_2`)
                .setLabel("الشخصية الثانية")
                .setStyle("SECONDARY")
        )

        let msg = await message.reply({
            content: `**قم بإختيار الشخصية الذي تريد سحب الغرض منها**`,
            components: [row]
        })

        const collector = msg.createMessageComponentCollector({ componentType: 'BUTTON', time: 20000 });
        collector.on('collect', async i => {
            if (i.user.id != message.author.id) return i.reply({
                content: `**⚠️ - ليس لديك صلاحيات لاستخدام هذا الاختيار**`,
                ephemeral: true
            })

            let row2 = new Discord.MessageActionRow().addComponents(
                new Discord.MessageButton()
                    .setCustomId(`giveitem_${message.author.id}_1`)
                    .setLabel("الشخصية الاولى")
                    .setStyle("SECONDARY"),

                new Discord.MessageButton()
                    .setCustomId(`giveitem_${message.author.id}_2`)
                    .setLabel("الشخصية الثانية")
                    .setStyle("SECONDARY")
            )

            await msg.delete();

            let msg2 = await message.reply({
                content: `**قم بإختيار الشخصية الذي تريد التحويل عليها**`,
                components: [row2]
            })

            const collector2 = msg2.createMessageComponentCollector({ componentType: 'BUTTON', time: 20000 });
            collector2.on('collect', async hamoudi => {
                if (hamoudi.user.id != message.author.id) return hamoudi.reply({
                    content: `**⚠️ -ليس لديك صلاحيات لاستخدام هذا الاختيار**`,
                    ephemeral: true
                })

                let main_author = message.author
                    , second_author = user
                    , count = parseInt(amount)

                let main_data = await userBase.findOne({ guild: message.guild.id, user: main_author.id })
                if (!main_data) {
                    main_data = new userBase({ guild: message.guild.id, user: main_author.id })
                    await main_data.save()
                }

                let second_data = await userBase.findOne({ guild: message.guild.id, user: second_author.id })
                if (!second_data) {
                    second_data = new userBase({ guild: message.guild.id, user: second_author.id })
                    await second_data.save()
                }

                i.customId.endsWith("1") ? main_data = main_data.c1 : main_data = main_data.c2
                hamoudi.customId.endsWith("1") ? second_data = second_data.c1 : second_data = second_data.c2

                let index = main_data.inv.findIndex(c => c.name.toLowerCase() == type.toLowerCase())
                if (index == -1) return msg2.edit({
                    content: `**⚠️ - عذرا لكنك لا تمتلك هذا الغرض في شخصيتك ${i.customId.endsWith("1") ? "الاولى" : "الثانية"}**`,
                    components: []
                })

                if (parseInt(main_data.inv[index].count) < parseInt(count)) return msg2.edit({
                    content: `**⚠️ - عذراً ولكن كمية الغرض في حقيبة شخصيتك ${i.customId.endsWith("1") ? "الاولى" : "الثانية"} أقل من الكمية الذي تريد تحويلها**`,
                    components: []
                })

                if (Number(main_data.inv[index].count) == parseInt(count)) {
                    main_data.inv.splice(index, 1)
                } else {
                    main_data.inv[index] = { name: type.toLowerCase(), count: parseInt(Number(main_data.inv[index].count) - Number(count)) }
                }
                await userBase.updateOne({ guild: message.guild.id, user: main_author.id },
                    { $set: { [`${i.customId.endsWith("1") ? "c1" : "c2"}.inv`]: main_data.inv } }
                );

                let index2 = second_data.inv.findIndex(c => c.name.toLowerCase() == type.toLowerCase())
                if (index2 == -1) {
                    second_data.inv.push({ name: type.toLowerCase(), count: parseInt(count) })
                } else {
                    second_data.inv[index2] = { name: type.toLowerCase(), count: parseInt(Number(second_data.inv[index2].count) + Number(count)) }
                }
                await userBase.updateOne({ guild: message.guild.id, user: second_author.id },
                    { $set: { [`${hamoudi.customId.endsWith("1") ? "c1" : "c2"}.inv`]: second_data.inv } }
                );

                let embed = new Discord.MessageEmbed()
                .setColor("YELLOW")
                .setAuthor({ name: "استعلام عن هوية", iconURL: message.author.avatarURL() })
                .setThumbnail(message.guild.iconURL())
                .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
                .setTimestamp()
                .setDescription(`** ✅ - تم تحويل المنتج بنجاح 

| المواطن : ${user}

| بواسطة : ${message.author}

| المنتج : \`${type.toLowerCase()}\`

| الى الشخصية : ${hamoudi.customId.endsWith("1") ? "الاولى" : "الثانية"}**`)

                await msg2.edit({
                    content: null,
                    embeds: [embed],
                    components: []
                })

            });

            collector2.on('end', collected => {
                if (collected.size > 0) return;

                msg2.delete();
            });
        });

        collector.on('end', collected => {
            if (collected.size > 0) return;

            msg.delete();
        });
    }
};
