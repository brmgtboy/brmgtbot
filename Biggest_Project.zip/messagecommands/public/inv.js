const userBase = require('../../Models/userBase')
module.exports = {
  name: `inv`,
  run: async (client, message, args, Discord) => {
    let user = message.mentions.users.first() || message.author

    let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setCustomId(`myinv_${message.author.id}_1`)
        .setLabel("الشخصية الاولى")
        .setStyle("SECONDARY"),

      new Discord.MessageButton()
        .setCustomId(`myinv_${message.author.id}_2`)
        .setLabel("الشخصية الثانية")
        .setStyle("SECONDARY")
    )

    let msg = await message.reply({
      content: `**قم بإختيار الشخصية الذي تريد الاستعلام عنها**`,
      components: [row]
    })

    const collector = msg.createMessageComponentCollector({ componentType: 'BUTTON', time: 20000 });
    collector.on('collect', async i => {
      if (i.user.id != message.author.id) return i.reply({
        content: `**⚠️ - ليس لديك صلاحيات لاستخدام هذا الاختيار**`,
        ephemeral: true
      })

      await i.deferUpdate();

      if (i.customId.startsWith("myinv")) {
        let data = await userBase.findOne({ guild: message.guild.id, user: user.id })
        if (!data) {
          data = new userBase({ guild: message.guild.id, user: user.id })
          await data.save()
        }

        i.customId.endsWith("1") ? data = data.c1 : data = data.c2

        const allinvs = [], max = 10, inv = [...data.inv];

        if (inv.length <= 0) return msg.edit({
          content: `**⚠️ - شخصيتك ${i.customId.endsWith("1") ? "الاولى" : "الثانية"} لا تملك اغراض داخل الحقيبة**`,
          components: []
        })

        while (inv.length) {
          allinvs.push(inv.splice(0, max));
        }

        function generateEmbed(page) {
          const embed = new Discord.MessageEmbed()
            .setTitle(`مجموع الاغراض داخل الصفحة ( ${allinvs[page].length} )`)
            .setColor("BLURPLE")
            .setTimestamp()
            .setThumbnail(message.guild.iconURL({ dynamic: true }))
            .setFooter({ text: `مجموع الاغراض ( ${data.inv.length} )`, iconURL: user.avatarURL({ dynamic: true }) })
            .setDescription(allinvs[page].map(d => `- ${d.name} : ${d.count}`).join("\n"));

          return embed;
        }

        var currentPage = 0;
        let row2 = new Discord.MessageActionRow().addComponents(
          new Discord.MessageButton()
            .setCustomId(`back`)
            .setLabel("رجوع")
            .setStyle("PRIMARY")
            .setDisabled(currentPage == 0),

          new Discord.MessageButton()
            .setCustomId(`next`)
            .setLabel("التالي")
            .setStyle("PRIMARY")
            .setDisabled(data.inv.length <= 10)
        )

        await msg.delete();

        let msg2 = await message.reply({
          content: null,
          embeds: [generateEmbed(currentPage)],
          components: [row2]
        });

        const collector2 = msg2.createMessageComponentCollector({ componentType: 'BUTTON', time: 120000 });
        collector2.on('collect', async (i2) => {
          if (i2.user.id != message.author.id) return;

          await i2.deferUpdate();

          if (i2.customId === 'back') {
            currentPage -= 1;

            if (currentPage < 0) currentPage = allinvs.length - 1;
          } else if (i2.customId === 'next') {
            currentPage += 1;

            if (currentPage === allinvs.length) currentPage = 0;
          }

          await row2.components[0].setDisabled(currentPage === 0);
          await row2.components[1].setDisabled(currentPage === allinvs.length - 1);

          await msg2.edit({
            embeds: [generateEmbed(currentPage)],
            components: [row2]
          });
        });

        collector2.on('end', collected => {
          if (collected.size > 0) return;

          msg2.delete();
        });

      }
    })

    collector.on('end', collected => {
      if (collected.size > 0) return;

      msg.delete();
    });
  }
};
