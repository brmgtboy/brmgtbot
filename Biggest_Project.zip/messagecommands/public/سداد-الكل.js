const userBase = require('../../Models/userBase')
module.exports = {
  name: `سداد-الكل`,
  run: async (client, message, args, Discord) => {
    let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setCustomId(`endall_${message.author.id}_1`)
        .setLabel("الشخصية الاولى")
        .setStyle("SECONDARY"),

      new Discord.MessageButton()
        .setCustomId(`endall_${message.author.id}_2`)
        .setLabel("الشخصية الثانية")
        .setStyle("SECONDARY")
    )

    let msg = await message.reply({
      content: `**قم بإختيار الشخصية الذي تريد سداد كل مخالفتها**`,
      components: [row]
    })

    const collector = msg.createMessageComponentCollector({ componentType: 'BUTTON', time: 20000 });
    collector.on('collect', async i => {
      if (i.user.id != message.author.id) return i.reply({
        content: `**⚠️ - ليس لديك صلاحيات لاستخدام هذا الاختيار**`,
        ephemeral: true
      })

      if (i.customId.startsWith("endall")) {
        let data = await userBase.findOne({ guild: message.guild.id, user: message.author.id })
        if (!data) {
          data = new userBase({ guild: message.guild.id, user: message.author.id })
          await data.save()
        }

        i.customId.endsWith("1") ? data = data.c1 : data = data.c2

        if (data.m5alfat.length <= 0) return msg.edit({
          content: `**⚠️ - عذراً ولكن الشخصية ${i.customId.endsWith("1") ? "الاولى" : "الثانية"} لا تملك أي نوع من المخالفات**`,
          components: []
        })

        let total_price = data.m5alfat.map(c => Number(c.price)).reduce((total, current) => total + current, 0)

        if (parseInt(data.bank) < parseInt(total_price)) return msg.edit({
          content: `**⚠️ - عذراً ولكن رصيد شخصيتك البنكي أقل من مبلغ جميع المخالفات وهو __${total_price}__**`,
          components: []
        })

        data.bank = parseInt(data.bank - total_price)
        data.m5alfat = []

        await userBase.updateOne({ guild: message.guild.id, user: message.author.id },
          {
            $set: {
              [`${i.customId.endsWith("1") ? "c1" : "c2"}`]: data
            }
          }
        );

        let embed = new Discord.MessageEmbed()
        .setColor("YELLOW")
        .setThumbnail(message.guild.iconURL())
        .setTimestamp()
        .setAuthor({ name: message.guild.name, iconURL: message.guild.iconURL() })
        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
        .setDescription(`** عزيزي المواطن : ${message.author}

تم سداد جميع المخالفات بنجاح - ✅ 

| سعر المخالفات : __${total_price}__**`)

        msg.edit({
          embeds: [embed],
          content: null,
          components: []
        })
      }
    })
  }
};
