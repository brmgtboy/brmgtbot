const userBase = require('../../Models/userBase')
  , guildBase = require('../../Models/guildBase')
module.exports = {
  name: `ايداع`,
  run: async (client, message, args, Discord) => {
    let db = await guildBase.findOne({ guild: message.guild.id })
    if (!db) {
      db = new guildBase({ guild: message.guild.id })
      await db.save();
    }

    let user_roles = message.member.roles.cache.map(c => c.id)
      , required_roles = db.tf3el.add_role

    if ((required_roles.every(val => user_roles.includes(val.toLowerCase())) && user_roles.length >= required_roles.length) == false) return message.reply({
      content: `**⚠️ - عذراً ، لا يمكنك استخدام هذا الامر لانك غير مُفعل**`,
      components: []
    })

    let amount = args[0]
    if (!amount || isNaN(amount)) return message.reply({
      content: `**⚠️ - يجب عليك تحديد الكمية الذي تريد ايداعها**`
    })

    let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setCustomId(`ida3_${message.author.id}_1`)
        .setLabel("الشخصية الاولى")
        .setStyle("SECONDARY"),

      new Discord.MessageButton()
        .setCustomId(`ida3_${message.author.id}_2`)
        .setLabel("الشخصية الثانية")
        .setStyle("SECONDARY")
    )

    let msg = await message.reply({
      content: `**قم بإختيار الشخصية الذي تريد الايداع فيها**`,
      components: [row]
    })

    const collector = msg.createMessageComponentCollector({ componentType: 'BUTTON', time: 20000 });
    collector.on('collect', async i => {
      if (i.user.id != message.author.id) return i.reply({
        content: `**⚠️ - ليس لديك صلاحيات لاستخدام هذا الاختيار**`,
        ephemeral: true
      })

      if (i.customId.startsWith("ida3")) {
        let data = await userBase.findOne({ guild: message.guild.id, user: message.author.id })
        if (!data) {
          data = new userBase({ guild: message.guild.id, user: message.author.id })
          await data.save()
        }

        const password = data.password
        if (!password) return msg.edit({
          content: `**⚠️ - عذرا ، لكنك لا تملك كلمة سر خاصة تواصل مع الدعم الفني**`,
          components: []
        })

        i.customId.endsWith("1") ? data = data.c1 : data = data.c2

        let total_amount = parseInt(amount)
        if (parseInt(data.cash) < total_amount) return msg.edit({
          content: `**⚠️ - عذرا ، ولكن رصيد شخصيتك ${i.customId.endsWith("1") ? "الاولى" : "الثانية"} أقل من المبلغ الذي تريد ايداعه**`,
          components: []
        })

        let msg2 = await msg.edit({ content: `**⏲️ - لديك 15 ثانية أرفق كلمة السر الخاصة بحسابك البنكي**`, components: [] })
        const collector3 = msg2.channel.createMessageCollector({ time: 15000 });
        collector3.on('collect', async m => {
          if (m.author.id != message.author.id) return;

          if (m.content != password) {
            msg2.edit({ 
              components: [], 
              content: `**❌ - عذراً ولكن كلمة السر التي قمت بأرفاقها غير صحيحة حاول مرة آخرى**` 
            })

            return collector3.stop();
          }

          await userBase.updateOne({ guild: message.guild.id, user: message.author.id },
            {
              $set: {
                [`${i.customId.endsWith("1") ? "c1" : "c2"}.bank`]: parseInt(data.bank) + total_amount,
                [`${i.customId.endsWith("1") ? "c1" : "c2"}.cash`]: parseInt(data.cash) - total_amount
              }
            }
          );

          m.delete().catch(() => 0)
          await msg.edit({
            content: `**:white_check_mark: - عملية إيداع ناجحة

المبلغ : __${total_amount}__

العضو : ${message.author}

الشخصية : ${i.customId.endsWith("1") ? "الاولى" : "الثانية"}**`,
            components: []
          })
          return collector3.stop();

        })
      } else return;
    })
  }
};
