const userBase = require('../../Models/userBase'), guildBase = require('../../Models/guildBase');
module.exports = {
  name: `هويتي`,
  run: async (client, message, args, Discord) => {
    let db = await guildBase.findOne({ guild: message.guild.id })
    if (!db) {
      db = new guildBase({ guild: message.guild.id })
      await db.save();
    }

    let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setCustomId(`checkId_${message.author.id}_1`)
        .setLabel("الشخصية الاولى")
        .setStyle("SECONDARY"),

      new Discord.MessageButton()
        .setCustomId(`checkId_${message.author.id}_2`)
        .setLabel("الشخصية الثانية")
        .setStyle("SECONDARY")
    )

    let msg = await message.reply({
      content: `قم بإختيار الشخصية الذي تريد الاستعلام عن هويتها`,
      components: [row]
    })

    const collector = msg.createMessageComponentCollector({ componentType: 'BUTTON', time: 20000 });
    collector.on('collect', async i => {
      if (i.user.id != message.author.id) return i.reply({
        content: `ليس لديك صلاحيات لاستخدام هذا الاختيار`,
        ephemeral: true
      })

      if (i.customId.startsWith("checkId")) {
        let data = await userBase.findOne({ guild: message.guild.id, user: message.author.id })
        if (!data) {
          data = new userBase({ guild: message.guild.id, user: message.author.id })
          await data.save()
        }

        i.customId.endsWith("1") ? data = data.c1 : data = data.c2

        if (!data.id || Object.keys(data.id)?.length <= 0) return msg.edit({
          content: `**⚠️ - عذرا ولكن هذه الشخصية لا تملك هوية لتعديلها**`,
          components: []
        })

        let embed = new Discord.MessageEmbed()
          .setColor("YELLOW")
          .setAuthor({ name: "استعلام عن هوية", iconURL: message.author.avatarURL() })
          .setThumbnail(message.guild.iconURL())
          .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
          .setTimestamp()
          .setDescription(`** | الأسم : ${data.id["name"]}

| العمر : ${data.id["age"]}

| مكان الميلاد : ${data.id["place"]}

| نوع الشخصية :${data.id["type"]}

| الوظيفة : ${data.id["job"]}

✅ - تم اصدار الهوية من قبل وزارة الداخلية **`)

        await msg.edit({ embeds: [embed], content: null, components: [] })
      } else return;
    })
  }
};
