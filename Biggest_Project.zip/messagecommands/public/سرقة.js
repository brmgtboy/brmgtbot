const guildBase = require('../../Models/guildBase')
    , userBase = require('../../Models/userBase')
    , { checkInv } = require("../../functions")
    , generator = require('generate-password');

module.exports = {
    name: `سرقة`,
    run: async (client, message, args, Discord) => {
        let type = message.content.split(" ").slice(1).join(" ")
        if (!type) return message.reply({ content: `**⚠️ - قم بتحديد النوع الذي تريد سرقه**` })

        let data = await guildBase.findOne({ guild: message.guild.id })
        if (!data) {
            data = new guildBase({ guild: message.guild.id })
            await data.save()
        }

        if (data.thefts.length <= 0) return message.reply({ content: `**⚠️ - لا يوجد سرقات تمت اضافتها حتى الان**` })

        let index = data.thefts.findIndex(c => c.name.toLowerCase() == type.toLowerCase())
        if (index == -1) return message.reply({ content: `**⚠️ - لا استطيع ايجاد هذا النوع من السرقات**` })

        data = data.thefts[index]

        let role = message.guild.roles.cache.get(data.role)
        if (!role) return;

        if (!message.member.roles.cache.has(role.id)) return message.reply({
            content: `**⚠️ - ليس لديك صلاحية لسرقة \`${data.name}\`**`
        })

        let row = new Discord.MessageActionRow().addComponents(
            new Discord.MessageButton()
                .setCustomId(`theft_${message.author.id}_1`)
                .setLabel("الشخصية الاولى")
                .setStyle("SECONDARY"),

            new Discord.MessageButton()
                .setCustomId(`theft_${message.author.id}_2`)
                .setLabel("الشخصية الثانية")
                .setStyle("SECONDARY")
        )

        let msg = await message.reply({
            content: `**قم بإختيار الشخصية الذي تريدها**`,
            components: [row]
        })

        const collector = msg.createMessageComponentCollector({ componentType: 'BUTTON', time: 20000 });
        collector.on('collect', async i => {
            if (i.user.id != message.author.id) return i.reply({
                content: `**⚠️ - ليس لديك صلاحيات لاستخدام هذا الاختيار**`,
                ephemeral: true
            })

            if (i.customId.startsWith("theft_")) {
                let db = await userBase.findOne({ guild: message.guild.id, user: message.author.id })
                if (!db) {
                    db = new userBase({ guild: message.guild.id, user: message.author.id })
                    await db.save()
                }

                i.customId.endsWith("1") ? db = db.c1 : db = db.c2

                if (db.inv.length <= 0) return msg.edit({
                    content: `**⚠️ - عذرا لكن انت لا تملك أغراض في حقيبة الشخصية ${i.customId.endsWith("1") ? "الاولى" : "الثانية"}**`,
                    components: []
                })

                let tools_names = data.tools.split(",").map(c => `${c.split(" ")[1]}`)
                    , user_inv_name = db.inv.map(c2 => `${c2.name}`)

                if ((tools_names.every(val => user_inv_name.includes(val.toLowerCase())) && user_inv_name.length >= tools_names.length) == false) return msg.edit({
                    content: `**⚠️ - عذراً لكنك لا تملك الاغراض المطلوبة للسرقة**`,
                    components: []
                })

                let toolss = data.tools.split(",").map(c => `${c.trim()}`)
                if (!checkInv(db.inv, toolss)) return msg.edit({
                    content: `**⚠️ - عذراً لكنك لا تملك الاغراض المطلوبة للسرقة**`,
                    components: []
                })

                const password = generator.generate({
                    length: 10,
                    numbers: true,
                    uppercase: true,
                });

                let msg2 = await msg.edit({
                    content: `**⏲️ - لديك 15 ثانية لفك هذا التشفير ||${password}||**`,
                    components: []
                })

                const collector2 = msg2.channel.createMessageCollector({ time: 15000 });
                collector2.on('collect', async m => {
                    if (m.author.id != message.author.id) return;

                    if (m.content != password) {
                        msg2.edit({
                            components: [],
                            content: `**❌ - فشلت السرقة لانك قمت بفك التشفير بشكل خاطئ

تم إرسال البلاغ لوزارة الداخلية - 🚔**`
                        })

                        return collector2.stop();
                    }

                    for (const toool of toolss) {
                        let [count, tool_name] = toool.split(" ")

                        let index = db.inv.findIndex(c => c.name.toLowerCase() == tool_name.toLowerCase())
                        if (Number(db.inv[index].count) == parseInt(count)) {
                            db.inv.splice(index, 1)
                        } else {
                            db.inv[index] = { name: tool_name.toLowerCase(), count: parseInt(Number(db.inv[index].count) - Number(count)) }
                        }
                    }

                    await userBase.updateOne({ guild: message.guild.id, user: message.author.id },
                        {
                            $set: {
                                [`${i.customId.endsWith("1") ? "c1" : "c2"}.inv`]: db.inv
                            }
                        }
                    );

                    m.delete().catch(() => 0)
                    await msg2.edit({
                        components: [],
                        content: `**✅ - تم فك الشفرة بنجاح 

| الرجاء الانتظار حتى يتم سحب المسروقات واستكمالها **`
                    }).then((mm) => {
                        setTimeout(async () => {
                            let wins = data.values.split(",").map(c => `${c.trim()}`)
                                , random = Math.floor(Math.random() * wins.length);

                            if (wins.length == 1) random = 0
                            let prize = wins[random]

                            let index2 = db.inv.findIndex(c => c.name.toLowerCase() == prize.toLowerCase())
                            if (index2 == -1) {
                                db.inv.push({ name: prize.toLowerCase(), count: 1 })
                            } else {
                                db.inv[index2] = { name: prize.toLowerCase(), count: parseInt(Number(db.inv[index2].count) + 1) }
                            }

                            await userBase.updateOne({ guild: message.guild.id, user: message.author.id },
                                {
                                    $set: {
                                        [`${i.customId.endsWith("1") ? "c1" : "c2"}.inv`]: db.inv
                                    }
                                }
                            );

                            let embed = new Discord.MessageEmbed()
                            .setColor("YELLOW")
                            .setThumbnail(message.guild.iconURL())
                            .setTimestamp()
                            .setAuthor({ name: "كشف حساب", iconURL: message.guild.iconURL() })
                            .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
                            .setDescription(`** ✅ - تم سرقة ${type.toLowerCase()} بنجاح 

| المنتجات المسروقة : ${prize}

| الى الشخصية : ${i.customId.endsWith("1") ? "الاولى" : "الثانية"}**`)

                            await mm.edit({ content: null, embeds: [embed] })
                        }, data.time)
                    })
                    return collector2.stop();
                });
            } else return;
        })
    }
};
