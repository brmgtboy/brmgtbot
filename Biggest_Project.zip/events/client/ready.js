const Blacklisted = require("../../Models/blacklisted")
  , guildBase = require("../../Models/guildBase")
  , { sleep } = require("../../functions")
  , Discord = require("discord.js")
  , { azkar_channel } = require("../../config/config.json")
  , azkar = require("azkar");

module.exports = {
  name: 'ready',
  run: async (client) => {
    console.log(`Logged in as ${client.user.tag}`)

    setInterval(function () {
      let result = azkar.random()

      let azkarch = client.channels.cache.get(azkar_channel)
      if (azkarch) {
        let zekr_embed = new Discord.MessageEmbed()
          .setColor("YELLOW")
          .setTitle(`${result.category}`)
          .setDescription(`${result.zekr}`)

        azkarch?.send({ embeds: [zekr_embed] }).catch(() => 0)
      }
    }, 300000)

    let db2 = await Blacklisted.find()
    db2.forEach(async data => {
      setTimeout(async function () {
        let guild = client.guilds.cache.get(data.guild)
        if (guild) {
          let member = guild?.members.cache.get(data.user)
          if (member) {
            member?.roles.cache.filter(role => role.name != "@everyone").map(role => role.id).forEach(role => {
              sleep(1000)
              member?.roles.remove(role).catch(() => 0)
            })
            sleep(3000)

            data.roles.forEach(role => {
              sleep(1000)
              member?.roles.add(role).catch(() => 0)
            })

            await Blacklisted.deleteMany({ guild: data.guild, user: data.user })
          }
        }
      }, data.time - Date.now())
    })

    let dob = await guildBase.find();
    dob.forEach(async data => {
      let guild = client.guilds.cache.get(data.guild)
      if (guild) {
        if (data.da5lya?.second_channel) {
          let channel = guild?.channels.cache.get(data.da5lya.second_channel)
          if (channel) {
            let messages = await channel?.messages.fetch({ limit: 100 })
            await channel?.bulkDelete(messages)

            sleep(7000)

            let embed = new Discord.MessageEmbed()
              .setColor("YELLOW")
              .setAuthor({ name: "قائمة المباشرين في الداخلية", iconURL: guild.iconURL() })
              .setDescription(`None`)
              .setFooter({ text: guild.name, iconURL: guild.iconURL() })
              .setTimestamp()

            await channel?.send({ embeds: [embed] }).then(msg => {
              setInterval(async function () {
                var db2 = await guildBase.findOne({ guild: guild.id })

                var m = "";

                db2.joins.forEach((user, i) => {
                  let check = guild.members.cache.get(user)
                  if (check) {
                    if (i + 1 > 25) return;

                    m += `**${i + 1}— ${check} <a:reds_true:1086613328744435834>**\n`
                  }
                })

                embed.setDescription(`${data.joins.length <= 0 ? "None" : m}`)
                sleep(2000)
                await msg.edit({ embeds: [embed] }).catch(() => 0)
              }, 60000)
            }).catch(() => 0)
          }
        }
      }
    })
  }
}