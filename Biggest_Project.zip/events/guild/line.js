const guildBase = require('../../Models/guildBase')
  , config = require("../../config/config.json")

module.exports = {
  name: `messageCreate`,
  run: async (message, client) => {
    if (message.author.bot || !message.guild) return;

    let db = await guildBase.findOne({ guild: message.guild.id })
    if (!db || !db.auto_line || !db.auto_line.channels) return;

    if (message.content == "خط" || message.content == `${config.prefix}خط`) {
      if (!message.member.permissions.has("8")) return;

      if (!db.auto_line.line) return message.reply({ 
        content: `**⚠️ - عذراً لكنني لا استطيع الوصول للخط**`
      })
      message.delete().catch(() => 0)

      await message.channel.send({ files: [db.auto_line.line] })
    } else {
      if (!db.auto_line.channels.includes(message.channel.id) || !db.auto_line.line) return;

      await message.channel.send({ files: [db.auto_line.line] })
    }
  }
};
