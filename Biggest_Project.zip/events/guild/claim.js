const { sleep, addpoints } = require("../../functions")
    , Panels = require('../../Models/Panels')
    , Discord = require('discord.js')
    , guildBase = require('../../Models/guildBase')

module.exports = {
    name: `interactionCreate`,
    run: async (interaction, client) => {
        if (!interaction.isButton()) return;

        if (interaction.customId.startsWith("claim")) {
            let topic = interaction.channel.topic.split("|")
                , panel_id = topic[1].trim()
                , userId = topic[0].trim();

            let user = interaction.guild.members.cache.get(userId)
            if (!user) return interaction.reply({
                content: `**⚠️ - لا أستطيع ايجاد صاحب التذكرة داخل السيرفر**`,
                ephemeral: true
            })

            if (user.id == interaction.user.id) return interaction.reply({
                content: `**⚠️ - ليس لديك الصلاحيات لأستلام التذكرة **`,
                ephemeral: true
            })

            let data = await Panels.findOne({ guild: interaction.guild.id, messageId: panel_id })
            if (!data) return interaction.reply({
                content: `**⚠️ - لا استطيع ايجاد معلومات بانل هذه التذكرة ربما تم حذفه**`,
                ephemeral: true
            })

            let db = await guildBase.findOne({ guild: interaction.guild.id })
            if (!db) {
                db = new guildBase({ guild: interaction.guild.id }).save();
            }

            if (!db.staff.role) return interaction.reply({
                content: `**⚠️ - لم يتم تعين رتبة الاداريين حتى الان**`,
                ephemeral: true
            })

            let role = interaction.guild.roles.cache.get(db.staff.role)
            if (!role) return interaction.reply({
                content: `**⚠️ - لا استطيع ايجاد هذه الرول \`${db.staff.role}\` داخل هذا السيرفر**`,
                ephemeral: true
            })

            if (!interaction.member.roles.cache.has(role.id)) return interaction.reply({
                content: `**⚠️ - لا يمكنك استخدام هذا الزر**`,
                ephemeral: true
            })

            const perms = interaction.channel.permissionOverwrites.cache.map(c => c)
            for (const perm of perms) {
                if (perm.id != user.id) {
                    sleep(2000)
                    await interaction.channel.permissionOverwrites.edit(perm.id, { VIEW_CHANNEL: false });
                }
            }
            sleep(5000)

            await interaction.channel.permissionOverwrites.edit(interaction.user.id, { VIEW_CHANNEL: true });
            sleep(2000)

            await interaction.message.components[0].components[1].setCustomId("unclaim").setLabel("ترك").setStyle("SECONDARY")
            sleep(2000)

            await interaction.message.edit({
                components: interaction.message.components
            })

            let hehea = new Discord.MessageEmbed()
                .setColor("YELLOW")
                .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL() })
                .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() })
                .setThumbnail(interaction.guild.iconURL())
                .setTimestamp()
                .setDescription(`**✅ - تم استلام التذكرة بنجاح

| من قبل الاداري : ${interaction.user}

كيف اقدر اخدمك عزيزي العضو : ${user}**`)

            await interaction.reply({ embeds: [hehea] })

            db.claimed.push({ channel: interaction.channel.id, by: interaction.user.id })
            await db.save()
            sleep(1000)

            addpoints(interaction.guild.id, interaction.user.id, "claim", 1)
        }
    }
};
