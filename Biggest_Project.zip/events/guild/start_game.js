const guildBase = require('../../Models/guildBase')
    , config = require("../../config/config.json")
    , Discord = require("discord.js")
    , { addpoints } = require("../../functions");

module.exports = {
    name: `interactionCreate`,
    run: async (interaction, client) => {
        if (!interaction.isModalSubmit()) return;

        if (interaction.customId.startsWith("start_gamex")) {
            const owner = interaction.fields.getTextInputValue('owner'),
                co_owner = interaction.fields.getTextInputValue('co_owner'),
                time = interaction.fields.getTextInputValue('time');

            let db = await guildBase.findOne({ guild: interaction.guild.id })
            if (!db || !db?.channels.main_game || !db?.channels.second_game) return interaction.reply({
                content: `**⚠️ - يجب تعين رومات الاقيام قبل استخدام الامر**`,
                ephemeral: true
            })

            let main_channel = interaction.guild.channels.cache.get(db.channels.main_game)
            if (!main_channel) return interaction.reply({
                content: `**⚠️ - لن اتمكن من الوصول لهذا الروم داخل السيرفر \`${db.channels.main_game}\`**`,
                ephemeral: true
            })

            let second_channel = interaction.guild.channels.cache.get(db.channels.second_game)
            if (!second_channel) return interaction.reply({
                content: `**⚠️ - لن اتمكن من الوصول لهذا الروم داخل السيرفر \`${db.channels.second_game}\`**`,
                ephemeral: true
            })

            addpoints(interaction.guild.id, interaction.user.id, "start_game", 1)

            let hehea = new Discord.MessageEmbed()
            .setColor("YELLOW")
            .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL() })
            .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() })
            .setThumbnail(interaction.guild.iconURL())
            .setTimestamp()
            .setDescription( `** ✅ - تم اضافة نقطة ادارية 

| نوع النقطة :  بدأ رحلة

| الاداري : ${interaction.user}**`)

            interaction.reply({embeds: [hehea], ephemeral: true })
            await interaction.message.edit({ content: `**:white_check_mark: - تم فتح القيم بنجاح**`, components: [] })

            main_channel?.send({
                files: [config.game_info],
                content: `**${interaction.guild.name} - إعـــلان رحـــلة**

**قائد الرحلة: ${owner}**

**مساعد قائد الرحلة: ${co_owner}**

**وقت الرحلة: ${time}**

|| @everyone ||`
            }).then(async msg => {
                await msg.react(`${config.game_emoji}`)

                await msg.channel.send({ files: [config.line] })
            })

            second_channel?.send({
                content: `**:white_check_mark: - تم فتح القيم**\n\n|| @everyone ||`
            })
        }
    }
};
