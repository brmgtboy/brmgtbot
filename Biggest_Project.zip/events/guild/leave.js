const { sleep } = require("../../functions")
    , guildBase = require('../../Models/guildBase')

module.exports = {
    name: `interactionCreate`,
    run: async (interaction, client) => {
        if (!interaction.isButton()) return;
        if (interaction.customId.startsWith("leave")) {
            let db = await guildBase.findOne({ guild: interaction.guild.id })
            if (!db) {
                db = new guildBase({ guild: interaction.guild.id }).save();
            }

            if (!db.police) return interaction.reply({
                content: `**⚠️ - لم يتم تعين رتبة المسؤولين عن الشرطة حتى الان**`,
                ephemeral: true
            })

            let role = interaction.guild.roles.cache.get(db.police)
            if (!role) return interaction.reply({
                content: `**⚠️ - لا استطيع ايجاد هذه الرول \`${db.police}\` داخل هذا الخادم**`,
                ephemeral: true
            })

            if (!interaction.member.roles.cache.has(role.id)) return interaction.reply({
                content: `**⚠️ - هذا الزر متاح لمسؤولين الشرطة فقط**`,
                ephemeral: true
            })

            let index = db.joins.findIndex(c => c == interaction.user.id)
            if (index == -1) return interaction.reply({
                content: `**⚠️ - انت غير مُسجل دخولك بعد**`,
                ephemeral: true
            })

            db.joins.splice(index, 1)
            await db.save()

            await interaction.reply({
                content: `** ❌ - تم تسجيل خروجك بنجاح **`,
                ephemeral: true
            })

        }
    }
};
