const Blacklisted = require("../../Models/blacklisted")
  , { sleep } = require("../../functions");

module.exports = {
  name: 'guildMemberAdd',
  run: async (member, client) => {
    let data = await Blacklisted.findOne({ user: member.user.id })
    if (!data) return;

    let guild = client.guilds.cache.get(data.guild)
    if (!guild) return;

    member.roles.cache.filter(role => role.name != "@everyone").map(role => role.id).forEach(role => {
      sleep(1000)
      member.roles.remove(role).catch(() => 0)
    })
    sleep(3000)

    data.blacklisted_roles.forEach(role => {
      sleep(1000)
      member.roles.add(role).catch(() => 0)
    })

    setTimeout(async function () {
      member.roles.cache.filter(role => role.name != "@everyone").map(role => role.id).forEach(role => {
        sleep(1000)
        member.roles.remove(role).catch(() => 0)
      })
      sleep(3000)

      data.roles.forEach(role => {
        sleep(1000)
        member.roles.add(role).catch(() => 0)
      })

      await Blacklisted.deleteMany({ guild: data.guild, user: data.user })
    }, data.time - Date.now())
  }
}