const { sleep } = require("../../functions")
    , guildBase = require('../../Models/guildBase')

module.exports = {
    name: `interactionCreate`,
    run: async (interaction, client) => {
        if (!interaction.isButton()) return;

        if (interaction.customId.startsWith("join")) {
            let db = await guildBase.findOne({ guild: interaction.guild.id })
            if (!db) {
                db = new guildBase({ guild: interaction.guild.id }).save();
            }

            if (!db.police) return interaction.reply({
                content: `**⚠️ - لم يتم تعين رتبة المسؤولين عن الشرطة حتى الان**`,
                ephemeral: true
            })

            let role = interaction.guild.roles.cache.get(db.police)
            if (!role) return interaction.reply({
                content: `**⚠️ - لا استطيع ايجاد هذه الرول \`${db.police}\` داخل هذا الخادم**`,
                ephemeral: true
            })

            if (!interaction.member.roles.cache.has(role.id)) return interaction.reply({
                content: `**⚠️ - هذا الزر متاح لمسؤولين الشرطة فقط**`,
                ephemeral: true
            })

            if (db.joins.includes(interaction.user.id)) return interaction.reply({
                content: `**⚠️ - عذراً ، لكنك قمت بتسجيل دخولك من قبل**`,
                ephemeral: true
            })

            db.joins.push(interaction.user.id)
            await db.save()

            await interaction.reply({
                content: `**✅ - تم تسجيل دخولك بنجاح **`,
                ephemeral: true
            })

        }
    }
};
